Arduino_AVRSTL
===============
Arduino library providing STL for ArduinoCore-avr and ArduinoCore-megaavr boards.

This library is based on [ciband/avr_stl](https://github.com/ciband/avr_stl) as well as [mike-matera/ArduinoSTL](https://github.com/mike-matera/ArduinoSTL).

